import React from 'react'
function Home() {
    return (
        <div className="homecont"> 
            <p>The content of the website will be displayed here</p>
        </div>
    )
}
export default Home;