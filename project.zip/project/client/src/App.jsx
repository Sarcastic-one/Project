
import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Registration from './registration'; 
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Login from './login';
import Home from './home';
function App() {
  return (
   <BrowserRouter>
   <Routes>
    <Route path='/register' element= {<Registration />}></Route>
    <Route path='/Login' element= {<Login />}></Route>
    <Route path='/Home' element={<Home />}></Route>
   </Routes>
   </BrowserRouter>
  );
}

export default App;

